export var x = 1;
export function f(x) {
	return x;
}