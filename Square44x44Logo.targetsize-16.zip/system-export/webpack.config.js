/** @type {import("../../../../").Configuration} */
module.exports = {
	output: {
		libraryTarget: "system"
	},
	node: {
		__dirname: false,
		__filename: false
	}
};
