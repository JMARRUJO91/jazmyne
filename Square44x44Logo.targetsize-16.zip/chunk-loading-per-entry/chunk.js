export default 42;
