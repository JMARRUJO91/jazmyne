/** @type {import("../../../../").Configuration} */
module.exports = {
	output: {
		library: {
			type: "system"
		}
	},
	node: {
		__dirname: false,
		__filename: false
	}
};
