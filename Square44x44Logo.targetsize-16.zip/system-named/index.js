/* This test verifies that when output.library is specified that the compiled bundle provides
 * the library name to System during the System.register
 */

it("should call System.register with a name", function() {});
