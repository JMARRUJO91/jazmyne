const foo = require("foo");

it("should use browser main field", () => {
	expect(foo).toBe("browser");
});
