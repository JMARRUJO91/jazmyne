/** @type {import("../../../../").Configuration} */
module.exports = {
	target: "electron-renderer",
	optimization: {
		minimize: false
	}
};
