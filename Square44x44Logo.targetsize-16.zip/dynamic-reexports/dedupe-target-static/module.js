export const value = 42;
