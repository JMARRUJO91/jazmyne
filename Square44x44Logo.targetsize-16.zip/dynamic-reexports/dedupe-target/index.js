export * from "./a";
export * from "./b";

throw new Error("Should not be loaded");
