/* This test verifies that when there is no output.library specified that the call to
 * System.register does not include a name argument.
 */

it("should call System.register without a name", function() {});
