var supportsArrowFn = require("../../../helpers/supportsArrowFunctionExpression");

module.exports = function (config) {
	return supportsArrowFn();
};
