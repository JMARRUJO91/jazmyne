/** @type {import("../../../../").Configuration} */
module.exports = {
	target: "node",
	performance: {
		hints: false
	}
};
