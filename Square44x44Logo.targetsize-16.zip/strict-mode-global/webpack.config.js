/** @type {import("../../../../").Configuration} */
module.exports = {
	target: "web"
};
